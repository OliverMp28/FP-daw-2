<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php











        /*
        Propuesta 3: Aplicación para gestionar y analizar reseñas de películas o series
Descripción del proyecto: Una aplicación para gestionar y analizar reseñas de películas o series donde los usuarios puedan compartir sus opiniones sobre los títulos que han visto. Al completar un formulario, los usuarios ingresarán información como el título de la película o serie, la fecha en la que la vieron, su puntuación y una reseña. Luego, la aplicación procesará estos datos usando las funciones de cadenas y fechas solicitadas, ofreciendo análisis automáticos y formateo de los datos.

Campos del formulario:
Título de la película o serie (texto)
Nombre del usuario (texto)
Fecha en que vio la película o serie (selector de fecha)
Puntuación del título (selección de 1 a 5)
Reseña de la película o serie (texto)
Uso de las funciones PHP solicitadas:






a) Funciones de cadena:
strlen:

Para contar el número de caracteres en la reseña.
Ejemplo: Validar que la reseña tenga una longitud mínima (por ejemplo, 50 caracteres) para asegurarse de que la opinión es significativa.
str_contains:

Para buscar palabras clave en la reseña, como "emocionante", "aburrida", "recomendar", "predecible".
Ejemplo: Detectar si el usuario menciona que la película o serie es "predecible" y mostrar una sugerencia para otro título con una trama más intrigante.
str_replace:

Para reemplazar palabras inadecuadas o lenguaje ofensivo en la reseña.
Ejemplo: Sustituir palabras vulgares con "***" o reemplazar nombres de personajes con alternativas si los usuarios usan spoilers.
trim:

Para eliminar espacios en blanco antes y después del título o la reseña.
Ejemplo: Limpiar el título de la película o la reseña para que no tenga espacios innecesarios.
ucwords:

Para capitalizar correctamente el título de la película o serie.
Ejemplo: Si un usuario escribe "star wars: una nueva esperanza" todo en minúsculas, transformarlo en "Star Wars: Una Nueva Esperanza".
explode e implode:

Para dividir la reseña en palabras y realizar análisis de palabras clave.
Ejemplo: Separar la reseña por palabras, buscar cuántas veces se repite una palabra específica, y luego volver a unir la reseña.
b) Funciones de fecha:
date():

Para mostrar la fecha en que se registró la reseña.
Ejemplo: Mostrar la fecha actual en que el usuario envió su opinión.
checkdate():

Para verificar que la fecha en la que el usuario vio la película o serie es válida.
Ejemplo: Validar que no hayan ingresado una fecha inexistente o fuera de un rango lógico (como ver una película en el futuro).
getdate():

Para obtener detalles de la fecha de visualización, como el día de la semana o el mes.
Ejemplo: Informar al usuario que vio la película o serie un domingo, y brindar una pequeña estadística sobre cuántos usuarios ven películas en ese día.
mktime():

Para crear una marca de tiempo a partir de la fecha en la que vio la película.
Ejemplo: Usar esta función para calcular cuántos días han pasado desde que el usuario vio la película y mostrar este dato en el resumen de la reseña.
strtotime():

Para convertir una cadena de texto a una fecha.
Ejemplo: Si el usuario ingresa "hace tres días" en lugar de una fecha específica, convertir esa expresión en una fecha precisa.
Estructura del proyecto (Modularidad y Coherencia):
Formulario HTML:

El usuario ingresa el título de la película o serie, su nombre, la fecha en la que la vio, su puntuación y una reseña.
Procesamiento en PHP:

Aplicar funciones como trim, ucwords, strlen y str_replace para validar y formatear correctamente los datos del título y la reseña.
Validar la fecha usando checkdate, calcular cuánto tiempo ha pasado desde que el usuario vio la película con mktime, y mostrar la fecha actual usando date().
Analizar la reseña buscando palabras clave con str_contains y segmentarla usando explode.
Salida/Confirmación:

Mostrar un resumen que incluya el título formateado correctamente, la fecha en que el usuario vio la película o serie, la puntuación, un análisis de la reseña (palabras clave) y cuánto tiempo ha pasado desde que la vio.
Flujo del proyecto (Coherencia):
El usuario completa el formulario: Ingresa el título de la película o serie, su nombre, la fecha en la que la vio, la puntuación y una reseña.
Procesamiento en el backend (PHP):
Validar que los datos sean correctos (longitud de la reseña, validez de la fecha).
Aplicar str_contains para buscar si se usan ciertas palabras clave como "excelente", "malo", "predecible", etc., para generar respuestas o sugerencias.
Convertir la fecha de visualización en un timestamp para comparar con la fecha actual y calcular cuántos días han pasado desde entonces.
Salida:
Mostrar un resumen con el título correctamente formateado, un análisis de la reseña (palabras clave encontradas) y cuántos días han pasado desde que vio la película o serie.
Originalidad:
Sugerencias de películas o series: Dependiendo de las palabras clave detectadas en la reseña, la aplicación podría sugerir otras películas o series. Por ejemplo, si el usuario describe la película como "aburrida", podrías sugerir títulos con mejores críticas.

Estadísticas personales: Al usar mktime y getdate, puedes proporcionar detalles como "Has visto esta película hace 12 días" o "La mayoría de los usuarios ven películas los fines de semana".

Posibilidades de expansión:
Base de datos: Almacenar todas las reseñas en una base de datos y permitir a los usuarios consultar las reseñas más recientes o populares.
Sistema de recomendación: Basado en las puntuaciones y palabras clave de las reseñas, puedes crear un sistema que recomiende películas o series similares.
Conclusión:
Al cambiar la temática a películas o series, mantienes el flujo lógico y el uso efectivo de las funciones PHP solicitadas, pero introduces un tema que podría atraer a un público más amplio. Además, es un proyecto que puede expandirse con varias funcionalidades adicionales como sistemas de recomendación, análisis de reseñas, y estadísticas de los usuarios.
        */
    ?>
</body>
</html>