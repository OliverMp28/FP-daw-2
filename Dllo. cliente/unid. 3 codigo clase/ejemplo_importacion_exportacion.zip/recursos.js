let meses = [
    'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 
    'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
];

const MAX_PERSONAS_POR_EVENTO = 125;

let libros = {
    'El señor de los anillos': 1954,
    'Cien años de soledad': 1967,
    '1984': 1949,
    'Don Quijote de la Mancha': 1605,
    'La Odisea': -800
};

