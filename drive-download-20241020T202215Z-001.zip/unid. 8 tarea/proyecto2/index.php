<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <head>
        <h1>Reseña de peliculas y series</h1>

        <form  action="datos_procesados.php" method="POST" name="preguntas_reseña">
            <label for="titulo">Inserte el titulo</label> <br>
            <input type="text" name="titulo" id="titulo"> <br>

            <label for="nombre">Cual es tu nombre</label> <br>
            <input type="text" name="nombre" id="nombre"> <br>

            <label for="fecha_visto">Fecha en la que viste esta serie o pelicula</label> <br>
            <input type="date" name="fecha_visto" id="fecha_visto"> <br>

            <label for="puntuacion">Puntuacion del 1 al 5 <i>(nota: la nota no debe ser mayor de 5)</i></label> <br>
            <input type="number" name="puntuacion" id="puntuacion" max="5"> <br>
            
            <label for="reseña">Cuestanos una reseña sobre lo que viste, es buena, es mala, aspectos que te gustaron y que no te gustaron, etc.</label> <br>
            <textarea name="reseña" id="reseña" cols="50" rows="10"></textarea> <br>

            <input type="submit" value="Enviar reseña" class="enviar_reseña">
        </form>

        <!--
        Campos del formulario:
        Título de la película o serie (texto)
        Nombre del usuario (texto)
        Fecha en que vio la película o serie (selector de fecha)
        Puntuación del título (selección de 1 a 5)
        Reseña de la película o serie (texto)
        -->
    </head>
    <p></p>
    <?php
    ?>
</body>
</html>