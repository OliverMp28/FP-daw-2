<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        $titulo = (isset($_POST['titulo']))? $_POST['titulo'] : null;
        $nombre = (isset($_POST['nombre']))? $_POST['nombre'] : null;
        $date = (isset($_POST['fecha_visto']))? $_POST['fecha_visto'] : null;
        $puntuacion = (isset($_POST['puntuacion']))? $_POST['puntuacion'] : null;
        $reseña = (isset($_POST['reseña']))? $_POST['reseña'] : null;

        echo "$titulo .. $nombre .. $date .. $puntuacion ..$reseña";

    ?>
</body>
</html>