<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        $conexion = new mysqli("localhost", "root", "", "centro");
        $conexion->set_charset("utf8"); 

        $consultar = "SELECT * FROM Alumnos";

        $resultado = $conexion->query($consultar);
        echo "Hay $resultado->num_rows alumnos<br>";

        // while($fila=$resultado->fetch_array()){
        //     echo "$fila[0]<br>$fila[1]<br>$fila[2]<br><br>";
        // }

        while($fila=$resultado->fetch_array(MYSQLI_ASSOC)){
            $dni_alumno = $fila["dni"];
            $nombre_completo = $fila["nombre_completo"];
            $edad_alumno=$fila["edad"];
    

            echo "$dni_alumno<br>$nombre_completo<br>$edad_alumno<br><br>";
        }

        $conexion->close();
    ?>
</body>
</html>