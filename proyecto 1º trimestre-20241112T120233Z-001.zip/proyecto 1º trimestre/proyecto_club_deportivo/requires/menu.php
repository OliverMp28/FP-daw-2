<nav>
    
    <ul>
        <!-- si $nivel es 0 entonces coloca los li que correspondan-->
         <?php if ($nivel === 0) {?>
            <li><a href="index.php">Inicio</a></li>
            <li><a href="./servicios/">Servicios</a></li>
            <li><a href="./testimonios/">Testimonios</a></li>
            <li><a href="./noticias/">Noticias</a></li>
            <li><a href="./citas/">Citas</a></li>
        <?php }

        //  si $nivel es 1 entonces coloca los li del siguiente nivel de carpetas
         if ($nivel === 1) {?>
            <li><a href="../index.php">Inicio</a></li>
            <li><a href="../servicios/">Servicios</a></li>
            <li><a href="../testimonios/">Testimonios</a></li>
            <li><a href="../noticias/">Noticias</a></li>
            <li><a href="../citas/">Citas</a></li>
        <?php }?>
    </ul>
</nav>