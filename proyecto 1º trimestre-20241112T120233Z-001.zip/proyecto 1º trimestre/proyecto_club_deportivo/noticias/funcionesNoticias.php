<?php
    

    /*esta funcion es para tener las 3 ultimas noticias que mostraria en la pagina principal
    * devuelve las 3 ultimas noticias en un array
    */
    
    function obtenerUltimasNoticias($conexion){
        $sentencia = "SELECT * FROM noticia
                        ORDER BY fecha_publicacion DESC
                        LIMIT ?";

        $consulta=$conexion->prepare($sentencia);

        $xUltimos = 3;
        $consulta->bind_param('i', $xUltimos);

        if ($consulta->execute() === false) { 
            die("Error en la ejecución de la consulta: " . $consulta->error);
        }

        $id = $titulo = $contenido = $imagen = $fecha_publicacion = null;
        $consulta->bind_result($id, $titulo, $contenido, $imagen, $fecha_publicacion);

        $consulta->execute();

        $noticias = array();
        /*de la consulta, mediante un while obtener todos los datos de las noticias y ponerlas en un array */
        while($consulta->fetch()){
            $noticias[] = array(
                'id' => $id,
                'titulo' => $titulo,
                'contenido' => $contenido,
                'imagen' => $imagen,
                'fecha_publicacion' => $fecha_publicacion
            );
        }

        return $noticias;
    }
?>