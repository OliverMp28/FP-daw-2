<?php
	session_start();
	session_destroy();
	session_reset();
	echo "<h1>Sesion destruida elige idioma de nuevo</h1>";
	header("Refresh: 3; URL=index.php");
	
?>