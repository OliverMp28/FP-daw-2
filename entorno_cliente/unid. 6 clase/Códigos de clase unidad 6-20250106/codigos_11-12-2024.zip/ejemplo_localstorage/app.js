"use strict"
//Funciones auxiliares--------------------------------------------------------
const mostrar_info=(datos_personas)=>{
    div_info.innerHTML="";
    for(let persona of datos_personas){
        for(let atributo in persona){
            div_info.innerHTML+=`<h4>${atributo}:${persona[atributo]}</h4>`;
        }    
    }
}

const guardar_info=(nombre_almacen,datos_personas)=>{
    localStorage.setItem(nombre_almacen,JSON.stringify(datos_personas));
}

const recuperar_info=(nombre_almacen)=>{
    return JSON.parse(localStorage.getItem(nombre_almacen)) ?? [];
}



//Seleccion del DOM-----------------------------------------------------------
const form=document.getElementById("formu");
const nombre=document.getElementById("nom");
const apellidos=document.getElementById("ape");
const edad=document.getElementById("edad");

const boton=document.getElementById("guardar");
const div_info=document.getElementById("info");

//------------------------------------------------------------------------------
let datos=recuperar_info("almacen");
mostrar_info(datos);




form.addEventListener("submit",
    (evento) => {
        evento.preventDefault();
        let valor_nombre=nombre.value.trim();
        let valor_apellidos=apellidos.value.trim();
        let valor_edad=parseInt(edad.value.trim());
        
        let nueva_persona={
            "nombre":valor_nombre,
            "apellidos":valor_apellidos,
            "edad":valor_edad
        }
        datos.push(nueva_persona);        

        guardar_info("almacen",datos);
        
        mostrar_info(datos);

        form.reset();
    });


