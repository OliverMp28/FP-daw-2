const lista = {
  'rec4f2RIftFCb7aHh':{
    id: 'rec4f2RIftFCb7aHh',
    title: 'albany table',
    company: 'marcos',
    image:
      'https://firebasestorage.googleapis.com/v0/b/chat-7d403.appspot.com/o/muebles%2F01_albany_table.jpg?alt=media&token=fe8f3d8c-27ea-49fb-afbc-cd3a9fd5a07e',
    price: 79.99,
  },
  'rec8kkCmSiMkbkiko':{
    id: 'rec8kkCmSiMkbkiko',
    title: 'accent chair',
    company: 'caressa',
    image:
      'https://firebasestorage.googleapis.com/v0/b/chat-7d403.appspot.com/o/muebles%2F02_accent_chair.jpg?alt=media&token=8751f618-1322-4dac-a4fc-ab1d0e3fc5c6',
    price: 25.99,
  },
  'recBohCqQsot4Q4II':{
    id: 'recBohCqQsot4Q4II',
    title: 'wooden table',
    company: 'caressa',
    image:
      'https://firebasestorage.googleapis.com/v0/b/chat-7d403.appspot.com/o/muebles%2F03_wooden_table.jpg?alt=media&token=d0c42974-ab71-494e-a196-723eb05a5eab',
    price: 45.99,
  },
  'recDG1JRZnbpRHpoy':{
    id: 'recDG1JRZnbpRHpoy',
    title: 'dining table',
    company: 'caressa',
    image:
      'https://firebasestorage.googleapis.com/v0/b/chat-7d403.appspot.com/o/muebles%2F04_dinning_table.jpg?alt=media&token=e7942ddf-d655-4e4e-9147-09e2ef56d920',
    price: 6.99,
  },
  'recNWGyP7kjFhSqw3':{
    id: 'recNWGyP7kjFhSqw3',
    title: 'sofa set',
    company: 'liddy',
    image:
      'https://firebasestorage.googleapis.com/v0/b/chat-7d403.appspot.com/o/muebles%2F05_sofa_set.jpg?alt=media&token=1dd193e5-8f68-45d6-9e68-5260775f5268',
    price: 69.99,
  },
  'recZEougL5bbY4AEx':{
    id: 'recZEougL5bbY4AEx',
    title: 'modern bookshelf',
    company: 'marcos',
    image:
      'https://firebasestorage.googleapis.com/v0/b/chat-7d403.appspot.com/o/muebles%2F06_modern_bookshelf.jpg?alt=media&token=6ed7f1e6-2b81-43fd-b508-32f4dcd101a7',
    price: 8.99,
  },
  'recjMK1jgTb2ld7sv':{
    id: 'recjMK1jgTb2ld7sv',
    title: 'emperor bed',
    company: 'liddy',
    image:
      'https://firebasestorage.googleapis.com/v0/b/chat-7d403.appspot.com/o/muebles%2F07_emperor_bed.png?alt=media&token=4b583ee3-bec7-48b7-9840-f49faa4ce224',
    price: 21.99,
  },
  'recmg2a1ctaEJNZhu':{
    id: 'recmg2a1ctaEJNZhu',
    title: 'utopia sofa',
    company: 'marcos',
    image:
      'https://firebasestorage.googleapis.com/v0/b/chat-7d403.appspot.com/o/muebles%2F08_utopia_sofa.jpg?alt=media&token=04a70616-88e5-4380-87c4-ca385cba8d50',
    price: 39.95,
  },
  'recvKMNR3YFw0bEt3':{
    id: 'recvKMNR3YFw0bEt3',
    title: 'entertainment center',
    company: 'liddy',
    image:
      'https://firebasestorage.googleapis.com/v0/b/chat-7d403.appspot.com/o/muebles%2F09_entertaiment_center.jpg?alt=media&token=43281598-0891-4d65-934b-f6071fca53eb',
    price: 29.98,
  },
  'recxaXFy5IW539sgM':{
    id: 'recxaXFy5IW539sgM',
    title: 'albany sectional',
    company: 'ikea',
    image:
      'https://firebasestorage.googleapis.com/v0/b/chat-7d403.appspot.com/o/muebles%2F10_albany_Sectional.jpg?alt=media&token=ffda5e39-8d94-4453-8e14-cfa2f29a9ff0',
    price: 10.99,
  },
  'recyqtRglGNGtO4Q5':{
    id: 'recyqtRglGNGtO4Q5',
    title: 'leather sofa',
    company: 'liddy',
    image:
      'https://firebasestorage.googleapis.com/v0/b/chat-7d403.appspot.com/o/muebles%2F11_leather_sofa.webp?alt=media&token=b6d69278-e5d0-4e5a-b679-68a669021fee',
    price: 9.99,
  },
};



