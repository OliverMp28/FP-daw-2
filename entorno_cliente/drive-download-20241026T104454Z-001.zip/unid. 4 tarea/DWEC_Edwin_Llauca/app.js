// app.js

// Seleccionamos todos los asientos
const asientos = document.querySelectorAll('.asiento');

// Agregamos un evento de clic a cada asiento
asientos.forEach(asiento => {
    asiento.addEventListener('click', () => {
        // Si el asiento está reservado, no hacemos nada
        if (asiento.classList.contains('reservado')) return;

        // Alternamos entre seleccionar y deseleccionar
        asiento.classList.toggle('seleccionado');
    });
});
