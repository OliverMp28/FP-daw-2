
//https://api.mymemory.translated.net/get

const texto_spa=document.getElementById("spa");
const texto_eng=document.getElementById("eng");



