
//http://api.weatherapi.com/v1/current.json?key=027e499e71bf4031b73155522211901&q=Granada


function crearFila(humedad, temperatura, icono) {
  const fila = document.createElement("tr");
  
  const td_humedad = document.createElement("td");
  td_humedad.classList.add("text-center");
  td_humedad.innerText = humedad+"%";

  const td_temperatura = document.createElement("td");
  td_temperatura.classList.add("text-center");
  td_temperatura.innerText = temperatura+"ºC";


  const imagen = document.createElement("img");
  imagen.src = icono;

  const td_icono = document.createElement("td");
  td_icono.classList.add("text-center");
  td_icono.appendChild(imagen);


 
  fila.appendChild(td_humedad);
  fila.appendChild(td_temperatura);
  fila.appendChild(td_icono);

  return fila;
}