const url = 'https://icanhazdadjoke.com/';


  fetch(url, {
    headers: {
      Accept: 'application/json',
    },
  });
 
