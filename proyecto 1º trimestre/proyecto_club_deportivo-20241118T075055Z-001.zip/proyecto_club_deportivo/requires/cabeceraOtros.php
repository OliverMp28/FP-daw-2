<header>
        <?php
            // echo getcwd();
            require_once "menu.php";
        ?>
        <div class="texto_cabecera">
            <h1><?php echo $titulo; ?></h1>
        </div>
        
</header>