<footer>
        <p>
            <a href="#">Política de Privacidad</a> |
            <a href="#">Términos y Condiciones</a> |
        </p>
        <p>
            &copy; 2021 Casino "LA RUINA". Todos los derechos reservados.
        </p>
</footer>