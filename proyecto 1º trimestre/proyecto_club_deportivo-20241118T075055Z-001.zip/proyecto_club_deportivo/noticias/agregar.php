<?php
    require_once "../config/config.php";
    require_once "../config/funciones.php";

    $conexion = conectar($nombre_host, $nombre_usuario, $password_db, $nombre_db);
    if (!$conexion) { 
        echo "Error en la conexión"; 
        die();
    } 
 
    // $consulta->close();
    // $conexion->close();


    //aca llamo a los archivos para las funciones necesarias
    require_once "../funciones/funcionesNoticias.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/css/otros.css">
    <script src="../assets/js/validacionFormulario.js" defer></script>
    <title>Agregar noticia nueva</title>
</head>
<body>
    <?php
        $nivel = 1;
        $titulo = "Agregar noticia nueva";
        require_once "../requires/cabecera.php"
    ?>
    
    <main>
        <form id="miFormulario" action="respuesta.php" method="post" enctype="multipart/form-data">
            <h2>Inserte los datos de la nueva noticia</h2>

            <label for="tituloNoticia">Titulo:</label>
            <input
                type="text"
                id="tituloNoticia"
                name="tituloNoticia"
                placeholder="Introduce el titulo de la noticia"
                required
            />
            <span class="error"></span>

        <!-- Contenido de la noticia -->
            <label for="contenidoNoticia">Contenido:</label>
            <textarea
                id="contenidoNoticia"
                name="contenidoNoticia"
                placeholder="Escribe el contenido de la noticia"
                rows="5"
                required
            ></textarea>
            <span class="error"></span>

        <!-- Imagen asociada a la noticia -->
            <label for="imagenNoticia">Imagen:</label>
            <input
                type="file"
                id="imagenNoticia"
                name="imagenNoticia"
                accept="image/*"
                required
            />
            <span class="error"></span>

        <!-- Fecha de publicación -->
            <label for="fechaPublicacion">Fecha de publicación:</label>
            <input
                type="date"
                id="fechaPublicacion"
                name="fechaPublicacion"
                required
            />
            <span class="error"></span>
           
            <button type="submit">Enviar</button>
        </form>
    </main>
</body>
</html>