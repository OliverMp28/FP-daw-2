<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/css/otros.css">
    <title>Noticias</title>
</head>
<body>
    <?php
        $titulo = "Noticias";
        require_once "../requires/cabeceraOtros.php"
    ?>


    <main>
        <section class="seccion_noticias">
            <!--aqui irian todas las noticias en una sola columna (uno encima de otra)-->
            <!--habrá un <a href="#">Leer más...</a> para abrir la noticia completa en otra pagina -->
            <!--todas las noticias estarán una encima de otra (varias filas)-->
            <!--aqui irian las noticias-->
            <div class="noticia">
                <img src="../assets/img/fondo1.avif" alt="Noticia 1">
                <div>
                    <h2>Título de la noticia</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vel ipsum vel dui scelerisque ultricies.</p>

                    <p class="fecha">Publicada el 15 de octubre de 2021</p>
                    <p class="autor">Por Autor</p>

                    <a href="ver.php">Leer más...</a>
                </div>  
            </div>

            <div class="noticia">
                <img src="../assets/img/fondo1.avif" alt="Noticia 2">
                <div>
                    <h2>Título de la noticia</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vel ipsum vel dui scelerisque ultricies.</p>
                    
                    <p class="fecha">Publicada el 15 de octubre de 2021</p>
                    <p class="autor">Por Autor</p>
                    
                    <a href="./noticiaCompleta.html">Leer más...</a>
                </div>
            </div>
            <!--...-->
            <div class="noticia">
                <img src="../assets/img/fondo1.avif" alt="Noticia 3">
                <div>
                    <h2>Título de la noticia</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vel ipsum vel dui scelerisque ultricies.</p>
                    
                    <p class="fecha">Publicada el 15 de octubre de 2021</p>
                    <p class="autor">Por Autor</p>

                    <a href="./noticiaCompleta.html">Leer más...</a>
                </div>
            </div>

            <div class="noticia">
                <img src="../assets/img/fondo1.avif" alt="Noticia 3">
                <div>
                    <h2>Título de la noticia</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vel ipsum vel dui scelerisque ultricies.</p>
                    
                    <p class="fecha">Publicada el 15 de octubre de 2021</p>
                    <p class="autor">Por Autor</p>

                    <a href="./noticiaCompleta.html">Leer más...</a>
                </div>
            </div>
        </section>
    </main>
</body>
</html>