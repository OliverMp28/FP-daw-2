<header>
        <?php
            // echo getcwd();
            require_once "requires/menu.php";
        ?>
        <div class="texto_cabecera">
            <h1>Depor</h1>
            <h2>Tu club deportivo</h2>            
        </div>
        
</header>