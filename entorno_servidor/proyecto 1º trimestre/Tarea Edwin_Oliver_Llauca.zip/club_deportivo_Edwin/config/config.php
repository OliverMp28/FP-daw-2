<?php
    // $nombre_host='localhost';
    // $nombre_usuario='root';
    // $password_db='';
    // $nombre_db="club_deportivo";


    //conexion con mysql por imagen docker
    $nombre_host = 'db'; // Nombre del servicio definido en docker-compose.yml
    $nombre_usuario = 'usuario'; // Debe coincidir con MYSQL_USER en docker-compose.yml
    $password_db = '1234'; // Debe coincidir con MYSQL_PASSWORD en docker-compose.yml
    $nombre_db = 'club_deportivo'; // Debe coincidir con MYSQL_DATABASE en docker-compose.yml    
?>