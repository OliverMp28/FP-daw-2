<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="POST">
        <label for="asignatura">inserte asignatura</label>
        <input type="text" id="asignatura" name="asignatura" required>

        <label for="anio">Inserte un año</label>
        <input type="number" id="anio" name="anio" required>

        <input type="submit" value="Enviar">
    </form>

    <?php
        if(true){
            $asignatura = null;
            $anio = null;

            if (isset($_POST['asignatura'])) {
                $asignatura = $_POST['asignatura'];
            }
            if (isset($_POST['anio'])) {
                $anio = $_POST['anio'];
            }
        }
    ?>
</body>
</html>