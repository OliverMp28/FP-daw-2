<?php
// Encabezados para permitir CORS
header("Access-Control-Allow-Origin: *"); // Permite todas las solicitudes de origen
header("Content-Type: application/json"); // Establecer tipo de contenido en JSON

// Configuración de la base de datos
require "config.php";
require "funciones.php";

try{
    $conn = conectar($nombre_host, $nombre_usuario, $password_db, $nombre_db);
}catch (mysqli_sql_exception $e) {
    http_response_code(500);
    echo json_encode(["error" => "Error al conectar con la base de datos"]);
    die();
}


?>