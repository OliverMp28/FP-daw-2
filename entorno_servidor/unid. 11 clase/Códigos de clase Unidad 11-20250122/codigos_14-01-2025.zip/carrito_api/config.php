<?php
    $nombre_host='localhost';
    $nombre_usuario='root';
    $password_db='';
    $nombre_db="muebles";
    $tabla_muebles='mobiliario';
    //poner el nombre de las tablas si hubiera mas
?>