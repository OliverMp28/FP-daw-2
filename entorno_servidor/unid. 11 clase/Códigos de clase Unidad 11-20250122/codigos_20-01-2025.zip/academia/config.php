<?php
    $nombre_host='localhost';
    $nombre_usuario='root';
    $password_db='';
    $nombre_db="academia";
    $tabla_asignaturas='asignaturas';
    //poner el nombre de las tablas si hubiera mas
?>