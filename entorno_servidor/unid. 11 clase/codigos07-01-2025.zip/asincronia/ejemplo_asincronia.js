"use strict";

const lista = [
  {
    title: "albany table",
    company: "marcos",
    image:
      "https://firebasestorage.googleapis.com/v0/b/chat-7d403.appspot.com/o/muebles%2F01_albany_table.jpg?alt=media&token=fe8f3d8c-27ea-49fb-afbc-cd3a9fd5a07e",
    price: 79.99,
  },
  {
    title: "accent chair",
    company: "caressa",
    image:
      "https://firebasestorage.googleapis.com/v0/b/chat-7d403.appspot.com/o/muebles%2F02_accent_chair.jpg?alt=media&token=8751f618-1322-4dac-a4fc-ab1d0e3fc5c6",
    price: 25.99,
  },
  {
    title: "wooden table",
    company: "caressa",
    image:
      "https://firebasestorage.googleapis.com/v0/b/chat-7d403.appspot.com/o/muebles%2F03_wooden_table.jpg?alt=media&token=d0c42974-ab71-494e-a196-723eb05a5eab",
    price: 45.99,
  },
  {
    title: "dining table",
    company: "caressa",
    image:
      "https://firebasestorage.googleapis.com/v0/b/chat-7d403.appspot.com/o/muebles%2F04_dinning_table.jpg?alt=media&token=e7942ddf-d655-4e4e-9147-09e2ef56d920",
    price: 6.99,
  },
];
