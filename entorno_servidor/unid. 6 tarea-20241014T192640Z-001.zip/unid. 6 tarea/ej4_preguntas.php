<?php
        $preguntas = [
            [
                'pregunta' => 'Quién interpreta a Wil turner en "Piratas del Caribe"?',
                'opciones' => ['Johnny Depp', 'Orlando Bloom', 'Geoffrey Rush', 'Keira Knightley'],
                'correcta' => 1
            ],
            [
                'pregunta' => '¿Qué actor da vida a Neo en "The Matrix"?',
                'opciones' => ['Keanu Reeves', 'Laurence Fishburne', 'Hugo Weaving', 'Carrie-Anne Moss'],
                'correcta' => 0
            ],
            [
                'pregunta' => '¿Quién interpreta a Forrest Gump en la película del mismo nombre?',
                'opciones' => ['Tom Hanks', 'Robin Wright', 'Gary Sinise', 'Sally Field'],
                'correcta' => 0
            ],
            [
                'pregunta' => '¿Quien es el protagonista de la pelicula Inception"?',
                'opciones' => ['Robert Downey Jr.', 'Chris Evans', 'Leonardo DiCaprio', 'Chris Hemsworth'],
                'correcta' => 2
            ],
            [
                'pregunta' => '¿Quién da vida a Indiana Jones en la saga de películas?',
                'opciones' => ['Sean Connery', 'Shia LaBeouf', 'Karen Allen', 'Harrison Ford'],
                'correcta' => 3
            ],
            [
                'pregunta' => '¿Quien es el compositor de la banda sonora de la pelicula "Dune"?',
                'opciones' => ['Marlon Brando', 'Mica Levi', 'John Williams', 'Hans Zimmer'],
                'correcta' => 3
            ],
            [
                'pregunta' => '¿En que pelicula leonardo Dicaprio obtuvo su primer oscar como mejor actor?',
                'opciones' => ['Titanic', 'Rapidos y Furiosos', 'El renacido', 'El lobo de Wall Street'],
                'correcta' => 2
            ],
            [
                'pregunta' => '¿Que compañia compró a fox?',
                'opciones' => ['Marvel', 'Disney', 'Universal', 'Warner Bros.'],
                'correcta' => 1
            ],
            [
                'pregunta' => '¿En que año se estrenó la pelicula de "Alien: el octavo pasajero"?',
                'opciones' => ['1979', '1991', '1985', '2001'],
                'correcta' => 0
            ],
            [
                'pregunta' => '¿En que pelicula de la saga star wars muere el personaje de dark vader"?',
                'opciones' => ['La amenaza fantasma', 'El retorno del jedi', 'El despertar de la fuerza', 'El ataque de los clones'],
                'correcta' => 1
            ]
        ];
        
    ?>