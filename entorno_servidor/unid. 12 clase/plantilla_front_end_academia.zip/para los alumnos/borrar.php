<?php

// Si el ID está presente, realizar la eliminación
if (isset($_GET['id'])) {

    $id_asignatura = (int)$_GET['id'];
    $apiUrl = 'http://localhost/academia/api.php?id='.$id_asignatura;
   
    if ($httpCode == 200) {
        header("Location: index.php");
        die();
    } else {
        echo $respuesta["error"];
    }
} else {
    echo "ID no indicado para eliminar.";
}
