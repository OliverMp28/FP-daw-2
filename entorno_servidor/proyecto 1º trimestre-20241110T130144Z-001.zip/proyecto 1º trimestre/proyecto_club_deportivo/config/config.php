<?php
    $nombre_host='localhost';
    $nombre_usuario='root';
    $password_db='';
    $nombre_db="centro";
    $tabla_alumnos='alumnos';
?>