-- Archivo SQL para la base de datos 'club_deportivo'

-- Creación de la base de datos
CREATE DATABASE IF NOT EXISTS club_deportivo;
USE club_deportivo;

-- Tabla 'socio'
CREATE TABLE socio (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    edad INT,
    usuario VARCHAR(30) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    telefono VARCHAR(15),
    foto VARCHAR(100)
);

-- Tabla 'servicio'
CREATE TABLE servicio (
    id INT AUTO_INCREMENT PRIMARY KEY,
    descripcion VARCHAR(100) NOT NULL,
    duracion INT NOT NULL,  -- en minutos
    precio DECIMAL(8, 2) NOT NULL
);

-- Tabla 'testimonio'
CREATE TABLE testimonio (
    id INT AUTO_INCREMENT PRIMARY KEY,
    autor INT NOT NULL,
    contenido TEXT NOT NULL,
    fecha DATE NOT NULL,
    FOREIGN KEY (autor) REFERENCES socio(id) ON DELETE CASCADE
);

-- Tabla 'noticia'
CREATE TABLE noticia (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(100) NOT NULL,
    contenido TEXT NOT NULL,
    imagen VARCHAR(100),
    fecha_publicacion DATE NOT NULL
);

-- Tabla 'citas'
CREATE TABLE citas (
    socio INT NOT NULL,
    servicio INT NOT NULL,
    fecha DATE NOT NULL,
    hora TIME NOT NULL,
    PRIMARY KEY (socio, servicio, fecha, hora),
    FOREIGN KEY (socio) REFERENCES socio(id) ON DELETE CASCADE,
    FOREIGN KEY (servicio) REFERENCES servicio(id) ON DELETE CASCADE
);

-- Datos de ejemplo para la tabla 'socio'
INSERT INTO socio (nombre, edad, usuario, password, telefono, foto) VALUES
('Juan Pérez', 30, 'jperez', '1234', '5551234567', '/uploads/juan.jpg'),
('María García', 25, 'mgarcia', '1234', '5557654321', '/uploads/maria.jpg');

-- Datos de ejemplo para la tabla 'servicio'
INSERT INTO servicio (descripcion, duracion, precio) VALUES
('Entrenamiento Personal', 60, 30.00),
('Masaje Deportivo', 45, 25.00),
('Clases de Yoga', 90, 20.00);

-- Datos de ejemplo para la tabla 'testimonio'
INSERT INTO testimonio (autor, contenido, fecha) VALUES
(1, 'Gran experiencia en el club, los entrenadores son muy atentos.', '2023-10-15'),
(2, 'Excelentes instalaciones y ambiente.', '2023-11-05');

-- Datos de ejemplo para la tabla 'noticia'
INSERT INTO noticia (titulo, contenido, imagen, fecha_publicacion) VALUES
('Nuevo Entrenador en el Club', 'Nos complace anunciar la llegada de un nuevo entrenador.', '/uploads/noticia1.jpg', '2023-10-01'),
('Horario Especial de Fin de Año', 'Consulta nuestros horarios para diciembre y enero.', '/uploads/noticia2.jpg', '2023-11-01');

-- Datos de ejemplo para la tabla 'citas'
INSERT INTO citas (socio, servicio, fecha, hora) VALUES
(1, 1, '2023-12-10', '10:00:00'),
(2, 2, '2023-12-11', '11:00:00');
