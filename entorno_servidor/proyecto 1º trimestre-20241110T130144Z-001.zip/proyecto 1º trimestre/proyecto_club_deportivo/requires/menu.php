<nav>
    <ul>
        <li><a href="#">Inicio</a></li>
        <li><a href="#">Servicios</a></li>
        <li><a href="#">Testimonios</a></li>
        <li><a href="./noticias/index.php">Noticias</a></li>
        <li><a href="#">Citas</a></li>
    </ul>
</nav>