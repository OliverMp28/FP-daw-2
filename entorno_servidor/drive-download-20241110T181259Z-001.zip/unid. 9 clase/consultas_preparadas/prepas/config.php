<?php
    $nombre_host='localhost';
    $nombre_usuario='root';
    $password_db='';
    $nombre_db="centro";
    $tabla_alumnos='alumnos';
    //poner el nombre de las tablas si hubiera mas
?>