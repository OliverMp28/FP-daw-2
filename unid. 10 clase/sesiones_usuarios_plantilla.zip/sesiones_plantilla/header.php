<div class="header-content">
        <?php
                require_once "utilidades.php";
                echo "<h1>Bienvenido a Mi Página Web</h1>";
                $pagina_actual=basename($_SERVER['PHP_SELF']);
                echo formulario_para_iniciar_sesion($pagina_actual);
        ?>
</div>        

       