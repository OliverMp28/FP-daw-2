<?php
  
	echo "<h1>Sesion destruida elige idioma de nuevo</h1>";
	header("Refresh: 3; URL=index.php");
	
?>