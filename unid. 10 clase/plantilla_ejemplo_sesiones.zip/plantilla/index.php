<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1><a href="sesion_ingles.php">Elije Inglés</a></h1>
    <h1><a href="sesion_spanish.php">Elije Español</a></h1>

    <form method="POST" action="destruir_sesion.php">
        <button type="submit">Destruir sesion</button>
    </form>
    <?php
        echo "<table border>";
        echo "<tr><td> Idioma Sesión </td><td> $idioma </td></tr>";
        echo "</table>";
    ?>
</body>
</html>